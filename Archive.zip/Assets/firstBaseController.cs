﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class firstBaseController : MonoBehaviour
{
    public static bool pickedOff;

    public AudioSource AS;
    // Start is called before the first frame update
    void Start()
    {
        AS = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.name == "baseball(Clone)")
        {
            Debug.Log("picked off!");
            AS.Play();
            pickedOff = true;
        }
    }

   // private void OnCollisionEnter(Collision other)
   // {
       // if (other.transform.gameObject.name == "baseball(Clone)")
        //{
          //  Debug.Log("picked off!");
           // AS.Play();
          //  pickedOff = true;
       // }
   // }
}
