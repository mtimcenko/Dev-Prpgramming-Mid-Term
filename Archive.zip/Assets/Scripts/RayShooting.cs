﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayShooting : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject ball;
    public float speed = 50;

    public float length = 1000f;
    public GameObject aimer;

    private Camera cam;

    private bool throwDelay;

    
 
    void Start () {
        

       // ball = GetComponent<GameObject>();
    }
 
    void Update(){
        Cursor.lockState = CursorLockMode.Locked;
        Ray myRay = Camera.main.ScreenPointToRay(Input.mousePosition);
       
        Debug.DrawRay(myRay.origin,myRay.direction*length,Color.red);
        RaycastHit myHit;

        //RaycastHit hit;
                  // if(Input.GetMouseButtonUp(0)){
                     //  Debug.Log("things");
                     //  Ray myRay = Camera.main.ScreenPointToRay(Input.mousePosition);
                     //  if(Physics.Raycast(myRay, out hit, 400.0f))
                     //  {
                      //     GameObject newBall = Instantiate(ball, transform.position, transform.rotation);
                      //     newBall.GetComponent<Rigidbody>().velocity = (hit.point - transform.position).normalized * speed;
                     //  }
                 //  }
        
        if (Physics.Raycast(myRay, out myHit, length))
        {
           // myHit.transform.Rotate(1,0,0);
           aimer.transform.position = myHit.point;
            
            if (Input.GetMouseButtonDown(0) && !throwDelay && FirstPerson.canThrow)
            {
                StartCoroutine(pitchDelay());
                GameObject insBall = Instantiate(ball);
                insBall.transform.SetParent(null);
                insBall.transform.rotation = transform.rotation;
                insBall.transform.position = this.transform.position;
            
            }
        }
    }

    IEnumerator pitchDelay()
    {
        throwDelay = true;
        yield return new WaitForSeconds(2);
        throwDelay = false;
    }
}
