﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class MovingBall : MonoBehaviour
{
    private float forceVar = 500;
     Rigidbody RB;
    //  AudioSource AS;
    // public AudioClip ball;
    // public AudioClip strike;
     private bool pitch;


     // Start is called before the first frame update
    void Start()
    {
       // AS = GetComponent<AudioSource>();
        RB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        RB.AddForce(transform.forward*forceVar);
    }

    private void OnTriggerEnter(Collider other)
    {

        if(other.transform.gameObject.name == "strike" && !pitch)
        {
           
            
            
            pitch = true;
          //  AS.clip = strike;
          //  AS.Play();

        }
         if (other.transform.gameObject.name == "ball" && !pitch)
         {
           
             pitch = true;
        //    AS.clip = ball;
          //  AS.Play();
            
           // Debug.Log("Ball!");
        }

         pitch = false;


         //forceVar = 0;
    }

    

    private void OnTriggerExit(Collider other)
    {
        
    }
}
