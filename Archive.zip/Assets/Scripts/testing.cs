﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{

    private bool canMove;

    public GameObject destinationObject;

    public GameObject dest2;

    public GameObject dest3;

    public GameObject dest4;

    public float distanceToObject;
    
    public float moveSpeed = 1.0f;

    public float rotateSpeed = .5f;

    public GameObject text;

   // public Canvas canvas;

    public Text firstText;

    public TextMeshProUGUI test;

    private bool close;
    private bool found2;
    private bool found3;
    private bool found4;
    private bool endGame;

    private float obj2Dist;
    public float obj3Dist;
    private float obj4Dist;
    

    //public Rigidbody RB;
    // Start is called before the first frame update
    void Start()
    {

       
       // canMove = true;
         StartCoroutine("waitStart");

        // firstText = text.GetComponent<Tex>();

        // RB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

        if (endGame)
        {
            transform.Translate(Vector3.left * Time.deltaTime * moveSpeed);
        }

        
        
        // VECTOR3.DISTANCE IS HOW YOU MEASURE DISTANCE BETWEEN TWO OBJECTS
        distanceToObject = Vector3.Distance(this.transform.position, destinationObject.transform.position);
        obj2Dist = Vector3.Distance(this.transform.position, dest2.transform.position);
        obj3Dist = Vector3.Distance(this.transform.position, dest3.transform.position);
        obj4Dist = Vector3.Distance(this.transform.position, dest4.transform.position);
        


        if (distanceToObject <= 5 && !close)
        {
            close = true;
            test.text = "First object located! It seems to be some sort of generator.";
           

            StartCoroutine("firstObj");
            canMove = false;
        }

        if (obj2Dist <= 5 && !found2)
        {
            found2 = true;
            test.text = "Wow! A satelite array!";
            StartCoroutine("secondObj");
            canMove = false;

        }

        if (obj3Dist <= 15 && !found3)
        {
            found3 = true;
            test.text = "You do not comprehend what this structure is.";

            StartCoroutine("thirdObj");
            canMove = false;
        }

        if (obj4Dist <= 15 && found2 && found3 && !found4)
        {
            found4 = true;

            test.text = "So here it is.";

            StartCoroutine("fourthObj");

            canMove = false;


        }

        // write code that shows that if the distance is close enough between you and the landmark, show text clue for next object
        // you will probably need to declare public text object(s) in your script so you can control when it shows the clue
        // you may need to declare more than one destinationObject (aka 'landmark') in your script so you know which one to set as your next destination
        if (canMove)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                // RB.useGravity = true;
                //  transform.Rotate(Vector3.left,moveSpeed);
                // RB.AddForce(transform.forward*moveSpeed);
                transform.Translate(Vector3.left * Time.deltaTime * moveSpeed);
            }

            if (Input.GetKey(KeyCode.DownArrow))
            {
                // RB.useGravity = true;
                // transform.Rotate(Vector3.right,moveSpeed);
                // RB.AddForce(transform.forward*moveSpeed*2);
                transform.Translate(Vector3.right * Time.deltaTime * moveSpeed);
            }

            if (Input.GetKey(KeyCode.LeftArrow))
            {
                // RB.useGravity = true;
                transform.Rotate(new Vector3(0, -1, 0), rotateSpeed);
                transform.Translate(Vector3.back * Time.deltaTime * moveSpeed);
            }

            if (Input.GetKey(KeyCode.RightArrow))
            {
                // RB.useGravity = true;
                transform.Rotate(new Vector3(0, 1, 0), rotateSpeed);
                transform.Translate(Vector3.forward * Time.deltaTime * moveSpeed);
            }

            if (Input.GetKey(KeyCode.Space))
            {
                // RB.useGravity = false;
                transform.Translate(Vector3.up * Time.deltaTime * moveSpeed);
            }

            if (Input.GetKey(KeyCode.RightShift))
            {
                //  RB.useGravity = false;
                transform.Translate(Vector3.down * Time.deltaTime * moveSpeed);
            }
        }
    }

    IEnumerator waitStart()
    {
        yield return new WaitForSeconds(3);

        test.text = "On 43-C, everyone is a slave to the hive mind.";
        
        yield return new WaitForSeconds(5);
        
            test.text = "You, however, have just broken free from it.";
            
            yield return new WaitForSeconds(5);
            
            test.text= "You have infinite power and can finally control your movements.";
            
            yield return new WaitForSeconds(5);

        test.text = "With this ultimate freedom, you have the irresistible urge to find 4 random objects.";
        
        yield return new WaitForSeconds(8);
        canMove = true;
        
        test.text = "Arrow keys to move, space to go up, rshift to go down";
        
        yield return new WaitForSeconds(4);

        test.text = "The firt object is hidden INSIDE the city. Good luck!";
        
        yield return new WaitForSeconds(5);
        test.text = "";


    }

    IEnumerator firstObj()
    {
        yield return new WaitForSeconds(5);

        test.text = "Your innate sense points you to the highest mountain. you must fly to it at once.";
        
        yield return new WaitForSeconds(6);

        test.text = "";
        canMove = true;


    }

    IEnumerator secondObj()
    {
        yield return new WaitForSeconds(5);
        test.text = "The satelites are pointing that way for a reason...";
        
        yield return new WaitForSeconds(4);

        test.text = "";
        canMove = true;
    }

    IEnumerator thirdObj()
    {
        yield return new WaitForSeconds(4);

        test.text = "Well, whatever this thing is, your extreme thirst to find objects is almost quenched.";
        
        yield return new WaitForSeconds(6);

        test.text = "To become free, you must find the UFO. It crashed somewhere in that canyon..";
        
        yield return new WaitForSeconds(5);

        test.text = "";
        canMove = true;
    }

    IEnumerator fourthObj()
    {
        yield return new WaitForSeconds(4);

        test.text = "Finally, your thirst for objects has been quenched... for now.";
        
        yield return new WaitForSeconds(5);

        test.text = "RETURNING TO HIVE MIND. FREEDOM = FALSE.";

        endGame = true;
    }
}
