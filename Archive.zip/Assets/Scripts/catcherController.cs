﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class catcherController : MonoBehaviour
{
    public static bool catcherUp;

    public static bool hitCatcher;

    public static bool hitCatcherOther;

    private MeshRenderer MR;

    public AudioSource AS;

    public CapsuleCollider CC;
    // Start is called before the first frame update
    void Start()
    {
        AS = GetComponent<AudioSource>();
        MR = GetComponent<MeshRenderer>();
        CC = GetComponent<CapsuleCollider>();
    }

    // Update is called once per frame
    void Update()
    {
        if (MR.enabled == true)
        {
            CC.enabled = true;
            catcherUp = true;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.name == "baseball(Clone)")
        {
            hitCatcherOther = true;
            hitCatcher = true;
            Destroy(other.gameObject);
            AS.Play();
        }
    }
}
