﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class runnerController : MonoBehaviour
{

    public static bool inPos;

    public Transform target;

    public float speed = 30.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        if (catcherController.hitCatcherOther)
        {
            float step = speed * Time.deltaTime;

            transform.position = Vector3.MoveTowards(transform.position, target.position, step);

            if (Vector3.Distance(transform.position, target.position) < 0.01f)
            {
                target.position *= -1.0f;
                speed = 0;
                inPos = true;
            }
        }
    }
}
