﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class StrikeHandler : MonoBehaviour
{
    public static int strikes;
    public TMP_Text myText;
    public GameObject myTextOBJ;
    AudioSource AS;
    public AudioClip strikeThree;
    public AudioClip strike;

    // Start is called before the first frame update
    void Start()
    {
        AS = GetComponent<AudioSource>();
        myTextOBJ = GameObject.Find("Count");
        myText = myTextOBJ.GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
        myText.text = "Strikes: " + strikes;

        
    }

    private void LateUpdate()
    {
        if (strikes >= 3)
        {
            StartCoroutine(strikeOut());
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        
        
        AS.clip = strike;
        if (!catcherController.catcherUp)
        {
            if (other.transform.gameObject.name == "baseball(Clone)")
            {


                Destroy(other.gameObject);
                AS.Play();
                strikes++;
                // Debug.Log("strike");
                // myText.text = "Strikes: " + strikes;


                if (strikes >= 3)
                {
                    ballHandler.balls = 0;
                    AS.clip = strikeThree;
                    AS.Play();
                    Debug.Log("out");
                }




            }
        }

    }

    IEnumerator strikeOut()
    {
        yield return new WaitForSeconds(3);
        strikes = 0;
    }
    
    
}
