﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class FirstPerson : MonoBehaviour
{

    public static bool catcherHitBool;
    public GameObject catcherGO;
    public GameObject rubber;
    private float distanceToRubber;

    public Rigidbody RB;
    public float forwardBackward;
    public float rightLeft;
    public float speed;
    public float moveSpeed = 5;
    public Vector3 inputVector;
    public Vector3 jumpSpeed = (new Vector3(0,0,0));
    public GameObject ball;
    public Rigidbody ballRB;
    private bool thrown;
    public bool jump;
    
    public TMP_Text myText;
    public GameObject myTextOBJ;
    public GameObject firstBase;

    public bool canMove;
    // Start is called before the first frame update
    public Camera cam1;
    public Camera cam2;
    public Camera cam3;
    public Camera firstBaseCam;
    public Camera firstRunnerCam;
    public Camera secondRunnerCam;

    private bool gotAStrikeout;

    private bool manOnFirst;

    public static bool finalAB;

    public static bool canThrow;
    private bool test;

    public bool isPitching;

    public AudioSource AS;

    public static bool donthitAgain;
    void Start()
    {
        AS = GetComponent<AudioSource>();
        secondRunnerCam.enabled = false;
        firstRunnerCam.enabled = false;
        firstBaseCam.enabled = false;
        cam1.enabled = false;
        cam2.enabled = false;
        cam3.enabled = false;
        jumpSpeed.y = 1000f;
        RB = GetComponent<Rigidbody>();

        ballRB = GetComponent<Rigidbody>();
        myTextOBJ = GameObject.Find("infoText");
        myText = myTextOBJ.GetComponent<TMP_Text>();
        StartCoroutine(startText());
        firstBase = GameObject.Find("firstBase");


    }

    // Update is called once per frame
    void Update()
    {

        if (firstBaseController.pickedOff)
        {
            StartCoroutine(endGame());
            firstBaseController.pickedOff = false;
        }

        if (runnerController.inPos)
        {
            StartCoroutine(finalPlay());
            runnerController.inPos = false;
        }

        if (catcherController.hitCatcher && !donthitAgain)
        {
            
            catcherController.hitCatcher = false;
            {
                myText.text = "Well done! you beamed him!";
                StartCoroutine(catcherHit());
            }
            
        }

        if (finalAB && StrikeHandler.strikes >= 3)
        {
            Debug.Log("wyd mmmmmate");
        }
        //canMove = true;
       
        if (ballHandler.balls >= 4)
        {
            manOnFirst = true;
            StartCoroutine(exitFirstBaseCam());
            firstBase.GetComponent<MeshRenderer>().enabled = true;
            myText.text = "You walked the batter. Pitch better.";
        }

        if (StrikeHandler.strikes >= 3)
        {
            gotAStrikeout = true;
            StartCoroutine(strikeOut());
        }

       

        if (gotAStrikeout || manOnFirst)
        {
            gotAStrikeout = false;
            manOnFirst = false;
            catcherGO.GetComponent<MeshRenderer>().enabled = true;
           
            StartCoroutine(catcherAB());
        }
       // canMove = true;
        distanceToRubber = Vector3.Distance(this.transform.position, rubber.transform.position);

        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");
        transform.Rotate(0, mouseX * 5, 0);

        Camera.main.transform.Rotate(-mouseY * 5, 0, 0);

        if (canMove)
        {
            if (distanceToRubber <= 5 && !isPitching)
            {
                myText.text = "Press enter/return to enter pitching mode.";
                if (Input.GetKeyDown(KeyCode.Return))
                {
                    isPitching = true;
                    StartCoroutine(enterPitchMode());
                    transform.rotation = new Quaternion(0,40,0,80);
                    transform.position = new Vector3(39.24f,2.4f,49.8f);
                    canMove = false;

                }
            }

            if (distanceToRubber > 5)
            {
                myText.text = "";
            }
            jump = Input.GetButton("Jump");

            forwardBackward = Input.GetAxis("Vertical");
            rightLeft = Input.GetAxis("Horizontal");



            inputVector = transform.forward * forwardBackward;

            inputVector += transform.right * rightLeft;
        }

        //if (Input.GetKeyDown(KeyCode.Mouse0))
       // {
           // ThrowBall();
       // }

        if (Input.GetKeyDown(KeyCode.A))
        {
            thrown = false;
        }
        
    }

    

    private void FixedUpdate()
    {
       // Debug.Log(thrown);
       // ballRB.velocity = (Vector3.forward*100);
        if (jump)
        {
            //   StartCoroutine("jumpDelay");
            //Debug.Log("here");
            RB.AddForce(jumpSpeed);
        }
        RB.velocity = (inputVector * moveSpeed * Time.fixedDeltaTime * 300)+ Physics.gravity*.69f;

        if (thrown)
        {
            Debug.Log("thrown");
            ball.GetComponent<Rigidbody>().velocity = (Vector3.forward * moveSpeed * Time.fixedDeltaTime * 300)+ Physics.gravity*.69f;
        }
    }

    void ThrowBall()
    {
        thrown = true;
        
        Debug.Log("heeeere");
        Instantiate(ball,new Vector3(this.transform.position.x+2,transform.position.y,transform.position.z),Quaternion.identity);
        
        
    }

     IEnumerator startText()
     {
         canThrow = false;
         canMove = false;
         myText.text = "Welcome to Capsule Baseball 2020.";
         yield return new WaitForSeconds(3);
         myText.text = "You are the pitcher for the best team in the pro capsule leagues, the Cappy Capsules.";
         yield return new WaitForSeconds(5);
         cam1.enabled = true;
         myText.text = "Your task is to quiet the dude on the other team who keeps talking smack to you.";
         yield return new WaitForSeconds(5);
         cam1.enabled = false;
         cam2.enabled = true;
         myText.text = "This dude right here. He hasn't played yet, but you have a feeling he's the pinch runner for the team based on his clear lack of baseball talent.";
         yield return new WaitForSeconds(5);
         cam2.enabled = false;
         myText.text = ("First thing's first though. You'll need to get through this inning.");
         yield return new WaitForSeconds(5);
         myText.text = "Left click to pitch the ball. Try to throw strikes!";
         yield return new WaitForSeconds(4);
         myText.text = "To pitch, you'll need to step on the rubber.";
         yield return new WaitForSeconds(4);
         myText.text = "Good luck! Pound that fastball!";
         yield return new WaitForSeconds(3);
         canThrow = true;


         myText.text = "";

         canMove = true;

     }

     IEnumerator enterPitchMode()
     {
         myText.text = "Well done! Time to pitch. Don't choke!";
         yield return new WaitForSeconds(2);
         myText.text = "";

     }

     IEnumerator exitFirstBaseCam()
     {
         firstBaseCam.enabled = true;
         yield return new WaitForSeconds(3);
         firstBaseCam.enabled = false;
         myText.text = "";
     }

     IEnumerator strikeOut()
     {
         myText.text = "Seeya! Nice pitching! 1 out.";
         yield return new WaitForSeconds(3);
       //  myText.text = "";
     }

     IEnumerator catcherAB()
     {
         canThrow = false;
         yield return new WaitForSeconds(5);
         myText.text = "Oh boy, it's the catcher batting.";
         yield return new WaitForSeconds(4);
         myText.text = "You know that if you're gonna shut this dude up, you need to let the catcher on base.";
         yield return new WaitForSeconds(4);
         myText.text = "If you let him on base, they'll likely put in a pinch runner for him...";
         yield return new WaitForSeconds(4);
         myText.text = "Well, time to do the deed. A sacrifice must be made to get this man on first.";
         yield return new WaitForSeconds(4);
         myText.text = "Hit him. It's the only way.";
         yield return new WaitForSeconds(4);
         myText.text = "";
         canThrow = true;

     }

     IEnumerator DelayCatcherAB()
     {
         yield return new WaitForSeconds(2);
         finalAB = true;
     }

     IEnumerator catcherHit()
     {
         catcherHitBool = true;
         canThrow = false;
         myText.text = "Well done! you beamed him!";
         yield return new WaitForSeconds(4);
         firstRunnerCam.enabled = true;
         myText.text = "A miracle! They're putting him in to pinch run!!!";
         yield return new WaitForSeconds(5);
         myText.text = "Awfully slow for a pinch runner...";
         firstRunnerCam.enabled = false;
         secondRunnerCam.enabled = true;
         yield return new WaitForSeconds(5);
         myText.text = "Go pinch runner! Go!";
         donthitAgain = true;
         yield return new WaitForSeconds(3);
         myText.text = "You begin to salivate at how easy to pick off he'll be.";
         yield return new WaitForSeconds(4);
         secondRunnerCam.enabled = false;
         firstBaseCam.enabled = true;
         myText.text = "He's making progress...";
         yield return new WaitForSeconds(3);
         myText.text = "Almost there...";
         yield return new WaitForSeconds(4);
         myText.text = "Still going...";
        


     }

     IEnumerator finalPlay()
     {
         canThrow = false;
         myText.text = "Finally.";
         yield return new WaitForSeconds(2);
         myText.text = "Now is your time. Picking this dude off at first will silence him.";
         yield return new WaitForSeconds(4);
         myText.text = "Throw to your first baseman. He won't see it coming. I promise.";
         firstBaseCam.enabled = false;
         canThrow = true;
         yield return new WaitForSeconds(4);
         myText.text = "";
     }

     IEnumerator endGame()
     {
         canThrow = false;
         canMove = true;
         AS.Play();
         myText.text = "Got him!!!! SEEEEYA!!!!!";
         yield return new WaitForSeconds(3);
         myText.text = "Mission complete! He won't be bothering you from the BENCH for the rest of the game.";
         yield return new WaitForSeconds(5);
         myText.text = "Thanks for playing!!!";


     }
     
     
     

     
     
    
}