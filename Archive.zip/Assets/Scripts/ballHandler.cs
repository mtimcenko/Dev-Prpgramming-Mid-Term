﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ballHandler : MonoBehaviour
{
    public TMP_Text myText;
    public GameObject myTextOBJ;
    AudioSource AS;

    public static int balls;

    public AudioClip ball;

    public AudioClip ball4;
    // Start is called before the first frame update
    void Start()
    {
        myTextOBJ = GameObject.Find("countBalls");
        myText = myTextOBJ.GetComponent<TMP_Text>();
        AS = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        myText.text = "Balls: " + balls;

        

    }

    private void LateUpdate()
    {
        if (balls >= 4)
        {
            balls = 0;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        AS.clip = ball;
        if (!catcherController.catcherUp)
        {
            if (other.transform.gameObject.name == "baseball(Clone)")
            {
                Destroy(other.gameObject);
                AS.Play();
                balls++;
                Debug.Log("ball");
                // myText.text = "Balls: " + balls;

                if (balls >= 4)
                {
                    StrikeHandler.strikes = 0;
                    AS.clip = ball4;
                    AS.Play();
                    Debug.Log("out");


                }

            }
        }

    }
}
