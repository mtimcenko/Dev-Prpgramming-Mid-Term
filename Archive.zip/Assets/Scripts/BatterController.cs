﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatterController : MonoBehaviour
{

    public MeshRenderer MR;
    // Start is called before the first frame update
    void Start()
    {
        MR = GetComponent<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (StrikeHandler.strikes >= 3)
        {
           // Debug.Log("batter out");
            transform.Translate(Vector3.down);
        }

        if (ballHandler.balls >= 4)
        {
            MR.enabled = false;
            transform.Translate(Vector3.down);
        }
    }
}
